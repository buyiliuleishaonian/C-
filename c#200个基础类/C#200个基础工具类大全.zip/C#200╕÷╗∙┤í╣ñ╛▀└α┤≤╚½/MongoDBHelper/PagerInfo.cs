﻿namespace MongoDBHelper
{
    public class PagerInfo
    {
        public int Page { get; set;}
        public int PageSize { get; set; }
        
    }
}